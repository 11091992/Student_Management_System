-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2015 at 03:21 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `soict`
--

-- --------------------------------------------------------

--
-- Table structure for table `38-cs879-cs-1-2011-2016`
--

CREATE TABLE `38-cs879-cs-1-2011-2016` (
  `id` int(6) default NULL,
  `name` varchar(50) default NULL,
  `registration_no` varchar(30) default NULL,
  `attendence` varchar(30) default NULL,
  `midsem` varchar(10) default NULL,
  `endsem` varchar(10) default NULL,
  `grade` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `38-cs879-cs-1-2011-2016`
--

INSERT INTO `38-cs879-cs-1-2011-2016` (`id`, `name`, `registration_no`, `attendence`, `midsem`, `endsem`, `grade`) VALUES
(1, 'garima', '11ics038', '31', '', '', NULL),
(3, 'ima', '11ics019', '43', '', '', NULL),
(7, 'akriti', '11ics035', '543', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `39-ma12-ec-1-2011-2016`
--

CREATE TABLE `39-ma12-ec-1-2011-2016` (
  `id` int(6) default NULL,
  `name` varchar(50) default NULL,
  `registration_no` varchar(30) default NULL,
  `attendence` varchar(30) default NULL,
  `midsem` varchar(10) default NULL,
  `endsem` varchar(10) default NULL,
  `grade` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `39-ma12-ec-1-2011-2016`
--


-- --------------------------------------------------------

--
-- Table structure for table `faculty_info`
--

CREATE TABLE `faculty_info` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `faculty_info`
--

INSERT INTO `faculty_info` (`id`, `name`, `employee_id`, `designation`, `email_id`, `password`, `phone_no`, `category`, `nationality`, `address`, `dob`, `gender`, `date_added`) VALUES
(4, 'XYZ', '123', 'Professor', 'xyz@gbu.ac.in', '123', '827971981791', 'gen', 'Indian', 'jsnjwd', '11/09/2000', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `id` int(200) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`id`, `username`, `password`) VALUES
(1, 'office', 'heyya');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(200) NOT NULL auto_increment,
  `registration_no` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `registration_no`, `password`) VALUES
(1, '11ics77', 'hey');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(200) NOT NULL auto_increment,
  `registration_no` varchar(250) NOT NULL,
  `sfname` varchar(250) NOT NULL,
  `smname` varchar(250) NOT NULL,
  `slname` varchar(250) NOT NULL,
  `ffname` varchar(250) NOT NULL,
  `fmname` varchar(250) NOT NULL,
  `flname` varchar(250) NOT NULL,
  `mofname` varchar(250) NOT NULL,
  `momname` varchar(250) NOT NULL,
  `molname` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL,
  `Xschool` varchar(250) NOT NULL,
  `Xp` varchar(250) NOT NULL,
  `Xgrade` varchar(250) NOT NULL,
  `XIIschool` varchar(250) NOT NULL,
  `XIIp` varchar(250) NOT NULL,
  `XIIgrade` varchar(250) NOT NULL,
  `mstatus` varchar(250) NOT NULL,
  `email_id` varchar(250) NOT NULL,
  `phone_no` varchar(250) NOT NULL,
  `domicile` varchar(250) NOT NULL,
  `domicile_number` varchar(250) NOT NULL,
  `passport_number` varchar(250) NOT NULL,
  `religion` varchar(250) NOT NULL,
  `other1` varchar(250) NOT NULL,
  `caste` varchar(250) NOT NULL,
  `other2` varchar(250) NOT NULL,
  `sub_caste` varchar(250) NOT NULL,
  `other3` varchar(250) NOT NULL,
  `handicap` varchar(250) NOT NULL,
  `minority` varchar(250) NOT NULL,
  `nationality` varchar(250) NOT NULL,
  `other4` varchar(250) NOT NULL,
  `address1` varchar(250) NOT NULL,
  `city1` varchar(250) NOT NULL,
  `tehsil1` varchar(250) NOT NULL,
  `district1` varchar(250) NOT NULL,
  `state1` varchar(250) NOT NULL,
  `country1` varchar(250) NOT NULL,
  `pin1` varchar(250) NOT NULL,
  `landline1` varchar(250) NOT NULL,
  `address2` varchar(250) NOT NULL,
  `city2` varchar(250) NOT NULL,
  `tehsil2` varchar(250) NOT NULL,
  `district2` varchar(250) NOT NULL,
  `state2` varchar(250) NOT NULL,
  `country2` varchar(250) NOT NULL,
  `pin2` varchar(250) NOT NULL,
  `landline2` varchar(250) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `substatus` varchar(250) NOT NULL,
  `college` varchar(250) NOT NULL,
  `programme` varchar(250) NOT NULL,
  `batch_from` varchar(250) NOT NULL,
  `batch_to` varchar(250) NOT NULL,
  `csession` varchar(250) NOT NULL,
  `admnthrough` varchar(250) NOT NULL,
  `feecat` varchar(250) NOT NULL,
  `unpaid` varchar(250) NOT NULL,
  `admsem` varchar(250) NOT NULL,
  `currsem` varchar(250) NOT NULL,
  `catquota` varchar(250) NOT NULL,
  `other5` varchar(250) NOT NULL,
  `subcatquota` varchar(250) NOT NULL,
  `class` varchar(250) NOT NULL,
  `section` varchar(250) NOT NULL,
  `sno` varchar(250) NOT NULL,
  `refOf` varchar(250) NOT NULL,
  `refBy` varchar(250) NOT NULL,
  `priority` varchar(250) NOT NULL,
  `app_id` varchar(250) NOT NULL,
  `admndate` varchar(250) NOT NULL,
  `admn_no` varchar(250) NOT NULL,
  `enrollno` varchar(250) NOT NULL,
  `rollno` varchar(250) NOT NULL,
  `admn_under` varchar(250) NOT NULL,
  `prog_type` varchar(250) NOT NULL,
  `allot_cat` varchar(250) NOT NULL,
  `allot_subcat` varchar(250) NOT NULL,
  `qualval` varchar(250) NOT NULL,
  `late_entry` varchar(250) NOT NULL,
  `eng_rate` varchar(250) NOT NULL,
  `qual_crit` varchar(250) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id`, `registration_no`, `sfname`, `smname`, `slname`, `ffname`, `fmname`, `flname`, `mofname`, `momname`, `molname`, `gender`, `dob`, `Xschool`, `Xp`, `Xgrade`, `XIIschool`, `XIIp`, `XIIgrade`, `mstatus`, `email_id`, `phone_no`, `domicile`, `domicile_number`, `passport_number`, `religion`, `other1`, `caste`, `other2`, `sub_caste`, `other3`, `handicap`, `minority`, `nationality`, `other4`, `address1`, `city1`, `tehsil1`, `district1`, `state1`, `country1`, `pin1`, `landline1`, `address2`, `city2`, `tehsil2`, `district2`, `state2`, `country2`, `pin2`, `landline2`, `remark`, `password`, `status`, `substatus`, `college`, `programme`, `batch_from`, `batch_to`, `csession`, `admnthrough`, `feecat`, `unpaid`, `admsem`, `currsem`, `catquota`, `other5`, `subcatquota`, `class`, `section`, `sno`, `refOf`, `refBy`, `priority`, `app_id`, `admndate`, `admn_no`, `enrollno`, `rollno`, `admn_under`, `prog_type`, `allot_cat`, `allot_subcat`, `qualval`, `late_entry`, `eng_rate`, `qual_crit`, `date_added`) VALUES
(1, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(3, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-07'),
(4, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-07'),
(5, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-07'),
(6, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-07'),
(7, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-08'),
(8, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-08'),
(9, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2015-03-09');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(100) NOT NULL auto_increment,
  `subject_code` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `class` varchar(50) NOT NULL,
  `section` varchar(200) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `total_lectures` varchar(10) NOT NULL,
  `credits` varchar(10) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `batch_from` varchar(50) NOT NULL,
  `batch_to` varchar(50) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subject_code`, `name`, `class`, `section`, `employee_id`, `total_lectures`, `credits`, `semester`, `batch_from`, `batch_to`, `date_added`) VALUES
(38, 'cs879', 'gh', 'cs', '1', '123', '12', '71', '2', '2011', '2016', '2015-03-08'),
(39, 'ma12', 'jnb', 'ec', '1', 'qn', 'ns', 'k', '', '2011', '2016', '2015-03-08');
